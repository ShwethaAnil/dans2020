package com.danskeit.training.basic;

public interface Printable{
	public static final double PI = 3.14;
	void print();
}