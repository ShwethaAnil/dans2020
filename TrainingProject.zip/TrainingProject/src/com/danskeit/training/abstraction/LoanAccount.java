package com.danskeit.training.abstraction;

public class LoanAccount extends Account {

	public LoanAccount(long acc_num, String acc_holder_name, double balance) {
		super(acc_num, acc_holder_name, balance);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double withdraw(int amount){ 
		//super.withdraw(amount);
		if(super.balance-amount > 10000) {
		balance=balance-amount;
		}else {
			System.out.println("Insufficient Balance");
		}
		
		return balance;
	}
}
