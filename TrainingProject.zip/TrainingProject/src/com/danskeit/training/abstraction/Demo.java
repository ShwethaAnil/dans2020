package com.danskeit.training.abstraction;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Account a1=new Account();
	}

}
