package com.danskeit.training.pl;

import java.util.Scanner;

import com.danskeit.training.inheritence.Account;
import com.danskeit.training.inheritence.CurrentAccount;
import com.danskeit.training.inheritence.SavingsAccount;

public class BankApp {

	public static void main(String[] args) {
		Account a1=new Account(123,"ss",456789);
		a1.setAcc_holder_name("Suma");
		a1.setBalance(5678);
		a1.setAcc_num(56677);
		System.out.println(a1);
		//upcasting
		Account sa=new SavingsAccount("S",8988777,1000);
		sa.setAcc_holder_name("Sanvi");
		sa.setAcc_num(5678);
		sa.setBalance(6789);
		System.out.println(sa);
		
		System.out.println(a1.withdraw(5678));
		
		System.out.println(sa.withdraw(6789));
		
		((SavingsAccount) sa).sample();//downcasting
		
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Welcome to SDFG Bank");
//		Account acc;
//		System.out.println("1. SavingsAccount 2.CurrentAccount");
//		switch(sc.nextInt()) {
//		case 1: System.out.println("Enter the details");
//		      acc=new SavingsAccount(sc.next(),sc.nextDouble(),sc.nextInt());
//		      break;
//		case 2: System.out.println("Enter the details");
//		     acc=new CurrentAccount("Goran",567890);
//		     break;
//		default:System.out.println("Invalid");
		//}
		
		

	}

}
