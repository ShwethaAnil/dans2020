package com.danskeit.training.pl;

interface Drawable{
	void draw();
	double area();	
}

interface Coloring{
	String getColor(String color);
	void draw();
}

class Rectangle implements Drawable, Coloring{
   private int length;
   private int breadth;
   
  
	public Rectangle(int length, int breadth) {
	this.length = length;
	this.breadth = breadth;
	}

	@Override
	public String getColor(String color) {
		// TODO Auto-generated method stub
		return color;
	}
	@Override
	public void draw() {
		System.out.println("Rectangle drawn");	
	}
	

	@Override
	public double area() {
		double area=breadth* length;
		return area;	
	}
	
}

public class InterfaceDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle d1=new Rectangle(12, 34);
		System.out.println(d1.area());
		d1.draw();
		System.out.println(d1.getColor("Red"));
				
	}

}
