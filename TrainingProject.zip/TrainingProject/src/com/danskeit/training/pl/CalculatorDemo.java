package com.danskeit.training.pl;

class Calculator{
	public int add(int n1,int n2) {
		System.out.println("2 ints");
		return n1+n2;
	}
	
	public int add(int n1,int n2,int n3) {
		System.out.println("3 ints");
		return n1+n2+n3;
	}
	
	public double add(float n1,int n2) {
		System.out.println("One float and one int");
		return n1+n2;
	}
	
	public double add(float n1,float n2) {
		System.out.println("Both Float"+n1+" "+n2);
		return n1+n2;
	}
	
	
}

public class CalculatorDemo {

	public static void main(String[] args) {
		Calculator c1=new Calculator();
		System.out.println(c1.add(12, (float)56.5));
		double d=234.5;
		float f=(float)d;
	}

}
