package com.danskeit.training.pl;

import com.danskeit.training.basic.Printable;

public class Interfacedemo implements Printable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Printable p1=new Interfacedemo();
		//Printable.PI=9.8;
		p1.print();
		System.out.println(Printable.PI);
	}

	@Override
	public void print() {
		System.out.println("Printing");
	}

}
