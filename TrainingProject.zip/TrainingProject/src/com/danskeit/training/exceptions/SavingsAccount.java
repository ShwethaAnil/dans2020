package com.danskeit.training.exceptions;

public class SavingsAccount extends Account {
	
	private int minBalance;
	//private int balance;

	public SavingsAccount(String acc_holder_name, double balance) {
		super(acc_holder_name, balance);
	}

	@Override
	public double withdraw(int amount){ 
		if(super.balance-amount > 1000) {
		balance=balance-amount;
		}else {
			System.out.println("Insufficient Balance");
		}
		return balance;
	}
	
	public void sample() {
		System.out.println("Child method");
	}
}
