package com.danskeit.training.day2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateExample {

	public static void main(String[] args) throws ParseException {
		Date d1=new Date();
		System.out.println(d1);
		
		System.out.println(d1.getMonth()+" "+(d1.getYear()+1900)+" "+d1.getDate()+" "+d1.getDay());
		Date dob=new Date(1987, 11, 23);
		System.out.println(dob);
		
		Calendar cal=Calendar.getInstance();
		Calendar cal1=new GregorianCalendar();
		System.out.println(cal);
		System.out.println(cal.get(Calendar.DAY_OF_MONTH));
		System.out.println(cal.get(Calendar.DAY_OF_YEAR));
		System.out.println(cal.get(Calendar.DATE));
		System.out.println(cal.get(Calendar.YEAR));
		//System.out.println(Calendar.YEAR);
		
		cal1.set(1987, 11, 23);
		System.out.println(cal1);
		
		
	   //convert date to string
		Date today=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("E dd-MM-yyyy hh:mm:ss");
		String s=sdf.format(today);
		System.out.println(s);
	   
		//String to Date
		String st="23/Nov/1987";
		SimpleDateFormat sd=new SimpleDateFormat("dd/MMM/yyyy");
		Date d=sd.parse(st);
		System.out.println("String to Date "+d);
		
		//java.time --java 8
		ZoneId zone=ZoneId.of("Europe/London");
		LocalDate ld=LocalDate.now();
		System.out.println(ld);
		LocalTime lt=LocalTime.now(zone);
		System.out.println(lt);
		
		LocalDateTime ldt=LocalDateTime.now();
		System.out.println(ldt);
		
		LocalDate dobl=LocalDate.of(1987, 11, 03);
		System.out.println(dobl);
		//Difference between date
		Period p=Period.between(ld, dobl);
		System.out.println(p);
		//differnce between time
		Duration duration=Duration.between(lt, LocalTime.of(22, 22, 22));
		System.out.println(duration);
		
	}

}
