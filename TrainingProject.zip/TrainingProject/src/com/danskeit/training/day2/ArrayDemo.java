package com.danskeit.training.day2;

public class ArrayDemo {

	public static void main(String[] args) {
		int n[]= {67,89,34,12,3,3,454};
		System.out.println("==============Traditional for loop");
		for(int i=0;i<n.length;i++){
		System.out.println(n[i]);
		}
		
		System.out.println("===========Enhanced For Loop");
		for(int a:n) {
			System.out.println(a);
		}
		int[] arr=new int[10];
//		arr[0]=98;
//		arr[1]=67;
//		arr[2]=2;
//		arr[3]=4567;
		System.out.println("===========Enhanced For Loop");
		for(int a:arr) {
			System.out.println(a);
		}
		
		
		int[][] tDarr= {{12,34,56,98},{45,12,41,34},{34,78,66,23}};
		
		System.out.println("=============================");
		for(int i[]:tDarr) {//row {45,12,41}
			for(int j:i) {//column  12 34 56
				System.out.print("\t"+j);
			}
			System.out.println();	
		}
		//int[][] tD=new int[3][3];
		System.out.println(tDarr.length);
		int le=tDarr[0].length;
		System.out.println(le);
		System.out.println("=============================");
		for(int i=0;i<tDarr.length;i++) {
			for(int j=0;j<tDarr.length;j++) {
				System.out.print("\t "+tDarr[i][j]);
			}
			System.out.println();
		}
		
	
		

	}

	
	
}
