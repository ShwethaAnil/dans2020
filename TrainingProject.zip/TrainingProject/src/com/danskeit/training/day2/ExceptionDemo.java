package com.danskeit.training.day2;

import java.util.Scanner;

public class ExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
//defensive approach
//int n1=sc.nextInt();
//int n2=sc.nextInt();
//if(n2>0) {
//double div=n1/n2;
//System.out.println(div);
//}
//int arr[]=new int[sc.nextInt()];
//if(arr.length>=7) {
//System.out.println(arr[7]);
//}
//String s=sc.next();
//if(s.length()>=6) {
//System.out.println(s.charAt(6));
//}

//exception Approach
int n1=sc.nextInt();
int n2=sc.nextInt();
try {
double div=n1/n2;
System.out.println(div);
}catch(Exception e) {
	
	e.printStackTrace();
	//System.exit(0);
}finally {
	sc.close();
}
//}catch(ArithmeticException e) {
//	System.out.println(e.getMessage());//print the message of exception
//}catch(RuntimeException e) {
//	e.printStackTrace();//trace of the exception
//}catch(Exception e) {
//	e.printStackTrace();
//}

System.out.println("Code continuees");





	}

}
