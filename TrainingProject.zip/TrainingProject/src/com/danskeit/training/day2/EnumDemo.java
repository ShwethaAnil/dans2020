package com.danskeit.training.day2;

import java.util.Scanner;

//enum TrafficSignal{
//	RED("Stop",60),ORANGE("Ready"),GREEN("Go");
//	String st;
//	int t;
//	TrafficSignal(String st){
//		this.st=st;
//	}
//	TrafficSignal(String st,int t){
//		this.st=st;
//		this.t=t;
//	}
//	public String getSt() {
//		return st;
//	}
//	public int getT() {
//		return t;
//	}
//	//public static final TrafficSignal RED=new TrafficSignal();
//	//public static final TrafficSignal ORANGE=new TrafficSignal();
//	//public static final TrafficSignal GREEN=new TrafficSignal();
//}


public class EnumDemo {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=sc.next();
		//traditional
		TrafficSignal[] val=TrafficSignal.values();
		for(int i=0;i<val.length;i++) {
			System.out.println(val[i]);
		}
		
		for(TrafficSignal tf:TrafficSignal.values()) {
			String enumValue=tf.toString();
			if(enumValue.equalsIgnoreCase(input)) {
			System.out.println(tf+" "+tf.ordinal()+" "+tf.getSt()+" "
			+tf.getT());
			}
		}
		sc.close();
	}

}
