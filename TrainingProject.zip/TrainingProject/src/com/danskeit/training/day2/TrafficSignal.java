package com.danskeit.training.day2;

public enum TrafficSignal {
	RED("Stop",60),ORANGE("Ready"),GREEN("Go");
	String st;
	int t;
	TrafficSignal(String st){
		this.st=st;
	}
	TrafficSignal(String st,int t){
		this.st=st;
		this.t=t;
	}
	public String getSt() {
		return st;
	}
	public int getT() {
		return t;
	}
}
