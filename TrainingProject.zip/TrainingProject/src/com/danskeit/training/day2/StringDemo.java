package com.danskeit.training.day2;

public class StringDemo {

	public static void main(String[] args) {
		String str="Danskeit";//literal pool//immutable
		String str1="Danskeit";
		
		System.out.println(str.hashCode());
		str="Pivate Limited";
		System.out.println(str.hashCode());
		
		String str2=new String("danskeit"); //heap
		String str3=new String("Danskeit"); //heap
		
		System.out.println(str==str1);//true
		System.out.println(str2==str3);//false
		//You want to compare objects and expecting boolean
		//equals
		System.out.println(str1.equals(str3));
		System.out.println(str1.equalsIgnoreCase(str2));
		//You want to compare objects and expecting int result
		System.out.println(str1.compareTo(str2));
		
		System.out.println(str);
		String str6=str.concat(" It Limited");
		System.out.println(str6);
		System.out.println(str);
		
		System.out.println(str.replace('a', 'e'));
		System.out.println(str2);
		
		System.out.println(str6.length());
		System.out.println(str6.charAt(3));
		System.out.println(str6.indexOf('L'));
		System.out.println(str6.lastIndexOf('L'));
		
		//name --> accept only letters
		//  [A-Z] --only uppercase
		// [A-Za-z]
		// [A-Za-z0-9]
		
		//matches
		String s="shwe";
		if(s.matches("[A-Za-z]{4,10}")) {
			System.out.println("String matches");
		}else {
			System.out.println("String not matches");
		}
		
		
		
		//isEmpty
		//concat
		//replace
		//
		//mutable version of string is StringBuffer and StringBuilder
				//StringBuffer --> ThreadSafe, Slower , Synchronized, 1.0
				//StringBuilder --> Not ThreadSafe, Faster, not synchronized, 1.5
		
		StringBuilder sb=new StringBuilder("Danskeit Private");
		System.out.println(sb);
		sb.append(" Limited Bangalore");
		System.out.println(sb);
		
//		sb.reverse();
//		System.out.println(sb);
//		System.out.println(sb.substring(0,6));
		//System.out.println(sb);
		
		String[] tokens=sb.toString().split(" ");
		System.out.println("========================");
		for(int i=0;i<tokens.length;i++) {
			System.out.println(tokens[i]);
		}
		System.out.println("-=======================");
		for(String s2:tokens) {
			System.out.println(s2);
		}
		
		String[] values=str.split(" ");
		for(String s1:values) {
			System.out.println(s1);
		}
		
	}

}
