package com.danskeit.training.day2;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

class Parent{
	
	public void display()throws Exception {
		
	}
}
class Child extends Parent{
	
	public void display()throws IOException {
		
	}
}

public class ExceptionDemo2 {

	public static void main(String[] args)throws FileNotFoundException,IOException {
		// TODO Auto-generated method stub
//try {
		FileOutputStream fos=new FileOutputStream("example.txt");
		fos.write(5678);
//}catch(FileNotFoundException e) {
//	e.printStackTrace();
//}
		fos.close();
	}

}
