package com.danskeit.training.inheritence;

public class SavingsAccount extends Account {
	
	private int minBalance;
	//private int balance;

	public SavingsAccount(String acc_holder_name, double balance,int minbalance) {
		super(acc_holder_name, balance);
		this.minBalance=minbalance;
	}

	//minbalance of 1000
	//method Overriding
	@Override
	public double withdraw(int amount){ 
		//super.withdraw(amount);
		if(super.balance-amount > 1000) {
		balance=balance-amount;
		}else {
			System.out.println("Insufficient Balance");
		}
		
		return balance;
	}
	
	public void sample() {
		System.out.println("Child method");
	}
}
