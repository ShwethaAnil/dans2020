package com.danskeit.training.accounts;

public class CurrentAccount extends Account {

	public CurrentAccount(String acc_holder_name, double balance) {
		super(acc_holder_name, balance);
		
	}

	public double withdraw(int amount){ 
		if(balance-amount > 10000) {
		balance=balance-amount;
		}else {
			System.out.println("Insufficient Balance");
		}
		
		return balance;
	}
}
