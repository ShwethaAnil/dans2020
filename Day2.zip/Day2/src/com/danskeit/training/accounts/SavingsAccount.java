package com.danskeit.training.accounts;

public class SavingsAccount extends Account {
	


	public SavingsAccount(String acc_holder_name, double balance) {
		super(acc_holder_name, balance);
	}

	@Override
	public double withdraw(int amount){ 
		if(super.balance-amount > 1000) {
		balance=balance-amount;
		}else {
			System.out.println("Insufficient Balance");
		}
		return balance;
	}
	
}
