package com.danskeit.training.accounts;

public class Account {
	private long acc_num; //instance variables
	private String acc_holder_name;
	protected double balance;
	
	public Account() {//no arg constructor
		
	}
	public Account( String acc_holder_name, double balance) {
		this.acc_holder_name = acc_holder_name;
		this.balance = balance;
	}
	
	static{
		System.out.println("Block of code1");
	}
	
	
	public Account(long acc_num, String acc_holder_name, double balance) {
		this.acc_num = acc_num;
		this.acc_holder_name = acc_holder_name;
		this.balance = balance;
	}

	public String toString() {
		return "Account [acc_num=" + acc_num + ", acc_holder_name=" + acc_holder_name + ", balance=" + balance + "]";
	}
	public long getAcc_num() {
		return acc_num;
	}

	public static void simpleMethod() {
		System.out.println("Static Method");
	}


	public void setAcc_num(long acc_num) {
		this.acc_num = acc_num;
	}




	public String getAcc_holder_name() {
		return acc_holder_name;
	}




	public void setAcc_holder_name(String acc_holder_name) {
		this.acc_holder_name = acc_holder_name;
	}




	public double getBalance() {
		return balance;
	}




	public void setBalance(double balance) {
		this.balance = balance;
	}




	
	public	double withdraw(int amount){ 
	
		balance=balance-amount;
		return balance;
	}
	
	public double deposit(int amount){ 
	
	balance=balance+amount;
	return balance;
	}
	
}
