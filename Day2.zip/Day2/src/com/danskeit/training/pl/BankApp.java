package com.danskeit.training.pl;

import java.util.Random;
import java.util.Scanner;

import com.danskeit.training.accounts.Account;
import com.danskeit.training.accounts.CurrentAccount;
import com.danskeit.training.accounts.SavingsAccount;


public class BankApp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome to SDFG Bank");
		do {
		System.out.println("1. Savings Account 2. Current Account 3. exit");
		int choice=sc.nextInt();
		if(choice==1) {
			System.out.println("Enter Your name and opening balance");
			Account a1=new SavingsAccount(sc.next(), sc.nextDouble());
			Random r=new Random();
			a1.setAcc_num(r.nextLong());
			System.out.println("Account created"+a1.getAcc_num());
			Outer:
			do {
			System.out.println("1.Withdraw\n 2.Desposit \n 3.View Balance \n 4.Exit");
			switch(sc.nextInt()) {
			case 1: System.out.println("Enter the amount to withdraw");
					double balance=a1.withdraw(sc.nextInt());
					System.out.println("After withdraw, remaining balance"+balance);
					break;
			case 2: System.out.println("Enter the amount to deposit");
					double bal=a1.deposit(sc.nextInt());
				    System.out.println("After withdraw, remaining balance"+bal);
				    break;
			case 3: System.out.println("Your balance is "+a1.getBalance());
					break;
			case 4: break Outer;
			default:
				System.out.println("Invalid choice");	
			}
			}while(true);
		}else if(choice==2) {
			System.out.println("Enter Your name and opening balance");
			Account a1=new CurrentAccount(sc.next(), sc.nextDouble());
			Random r=new Random();
			a1.setAcc_num(r.nextLong());
			System.out.println("Account created"+a1.getAcc_num());
			Outer:
			do {
			System.out.println("1.Withdraw\n 2.Desposit \n 3.View Balance \n 4.Exit");
			switch(sc.nextInt()) {
			case 1: System.out.println("Enter the amount to withdraw");
					double balance=a1.withdraw(sc.nextInt());
					System.out.println("After withdraw, remaining balance"+balance);
					break;
			case 2: System.out.println("Enter the amount to deposit");
					double bal=a1.deposit(sc.nextInt());
				    System.out.println("After withdraw, remaining balance"+bal);
				    break;
			case 3: System.out.println("Your balance is "+a1.getBalance());
					break;
			case 4: break Outer;
			default:
				System.out.println("Invalid choice");	
			}
			}while(true);
		}
		else if(choice ==3) {
			System.out.println("Thank You");
			sc.close();
			System.exit(0);
		}else {
			System.out.println("Invalid Choice");
		}
		}while(true);

	}

}
